import torch
from torch_geometric.data import InMemoryDataset
from os.path import join, isfile
from os import listdir
import numpy as np
import os.path as osp
from dataset.imports.read_abide_stats_parall import read_data
import torch.nn.functional as F
from torch_geometric.loader import DataLoader
from utils.seed_setting import seed_torch,seed
seed_torch(seed)
class OSFDataset(InMemoryDataset):
    def __init__(self, root, name, transform=None, pre_transform=None):
        self.root = root
        self.name = name
        self.num_tasks = 1
        super(OSFDataset, self).__init__(root,transform, pre_transform)
        self.data, self.slices = torch.load(self.processed_paths[0])
        label = self.data['y']
        onehot = F.one_hot(label, num_classes=2)
        self.data['y'] = onehot
        print('1')

    @property
    def raw_file_names(self):
        data_dir = osp.join(self.root,'raw')
        onlyfiles = [f for f in listdir(data_dir) if osp.isfile(osp.join(data_dir, f))]
        onlyfiles.sort()
        return onlyfiles
    @property
    def processed_file_names(self):
        return  'data.pt'

    def download(self):
        # Download to `self.raw_dir`.
        return

    def process(self):
        # Read data into huge `Data` list.
        self.data, self.slices = read_data(self.raw_dir)

        if self.pre_filter is not None:
            data_list = [self.get(idx) for idx in range(len(self))]
            data_list = [data for data in data_list if self.pre_filter(data)]
            self.data, self.slices = self.collate(data_list)

        if self.pre_transform is not None:
            data_list = [self.get(idx) for idx in range(len(self))]
            data_list = [self.pre_transform(data) for data in data_list]
            self.data, self.slices = self.collate(data_list)

        torch.save((self.data, self.slices), self.processed_paths[0])

    def __repr__(self):
        return '{}({})'.format(self.name, len(self))


def benchmark_exp( dataset,  batch_size):

    datalen = len(dataset.raw_file_names)
    tensor = torch.tensor(range(datalen))
    split_ratio = 0.8

    # Determine the number of elements in each split
    num_train = int(len(tensor) * split_ratio)
    num_test = len(tensor) - num_train

    # Generate random indices for the split
    indices = torch.randperm(len(tensor))

    # Split the indices into training and testing sets
    train_indices = indices[:num_train]
    test_indices = indices[num_train:]




    # train_dataset = dataset[train_idx]
    semi_dataset = dataset[train_indices]
    # val_dataset = dataset[val_idx]
    test_dataset = dataset[test_indices]

    # train_loader = DataLoader(train_dataset, batch_size, shuffle=True)
    train_loader = DataLoader(semi_dataset, batch_size, shuffle=True)
    # val_loader = DataLoader(val_dataset, batch_size, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size, shuffle=False)



    return train_loader, test_loader