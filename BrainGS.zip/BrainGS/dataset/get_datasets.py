import torch

from .polymer import PolymerRegDataset
from ogb.graphproppred import PygGraphPropPredDataset
from dataset.imports.ABIDEDataset import ABIDEDataset
from dataset.imports.ADHDDataset import ADHDDataset
from dataset.imports.OSFDataset import OSFDataset
import os.path as osp
from utils.seed_setting import seed_torch,seed
seed_torch()
import re
import torch_geometric.transforms as T
from dataset.feature_expansion import FeatureExpander
from torch_geometric.datasets import MNISTSuperpixels
# from image_dataset import ImageDataset
from torch_geometric.datasets import TUDataset
from utils.seed_setting import seed_torch,seed
seed_torch(seed)


def get_dataset(args, load_path, load_unlabeled_name="None",sparse=True, feat_str="deg+ak3+renone", root=None):
    if load_unlabeled_name=='None':
        if args.dataset.startswith('plym'):
            return PolymerRegDataset(args.dataset, load_path)
        elif args.dataset.startswith('ogbg'):
            return PygGraphPropPredDataset(args.dataset, load_path)
        elif args.dataset == 'ADHD200':
            path = '/home/lingyuanmeng/NUDT/BRAIN/AutoGCL-master/ADHD_process/ADHD/adhd/data_processed'
            return ADHDDataset(path, args.dataset)
        elif args.dataset == 'OSF':
            path = '/home/lingyuanmeng/NUDT/BRAIN/AutoGCL-master/OSF/osf_processed'
            return OSFDataset(path, args.dataset)
        elif args.dataset == 'ABIDE':
            path = '/home/lingyuanmeng/NUDT/BRAIN/AutoGCL-master/ABIDE/cpac/filt_noglobal'
            return ABIDEDataset(path, args.dataset)

        else:
            if root is None or root == '':
                path = osp.join(osp.expanduser('~'), 'pyG_data', args.dataset)
            else:
                path = osp.join(root)

            degree = feat_str.find("deg") >= 0
            onehot_maxdeg = re.findall("odeg(\d+)", feat_str)
            onehot_maxdeg = int(onehot_maxdeg[0]) if onehot_maxdeg else None
            k = re.findall("an{0,1}k(\d+)", feat_str)
            k = int(k[0]) if k else 0
            groupd = re.findall("groupd(\d+)", feat_str)
            groupd = int(groupd[0]) if groupd else 0
            remove_edges = re.findall("re(\w+)", feat_str)
            remove_edges = remove_edges[0] if remove_edges else 'none'
            edge_noises_add = re.findall("randa([\d\.]+)", feat_str)
            edge_noises_add = float(edge_noises_add[0]) if edge_noises_add else 0
            edge_noises_delete = re.findall("randd([\d\.]+)", feat_str)
            edge_noises_delete = float(
                edge_noises_delete[0]) if edge_noises_delete else 0
            centrality = feat_str.find("cent") >= 0
            coord = feat_str.find("coord") >= 0

            pre_transform = FeatureExpander(
                degree=degree, onehot_maxdeg=onehot_maxdeg, AK=k,
                centrality=centrality, remove_edges=remove_edges,
                edge_noises_add=edge_noises_add, edge_noises_delete=edge_noises_delete,
                group_degree=groupd).transform

            if 'MNIST' in args.dataset or 'CIFAR' in args.dataset:
                if args.dataset == 'MNIST_SUPERPIXEL':
                    train_dataset = MNISTSuperpixels(path, True,
                                                     pre_transform=pre_transform, transform=T.Cartesian())
                    test_dataset = MNISTSuperpixels(path, False,
                                                    pre_transform=pre_transform, transform=T.Cartesian())
                else:
                    train_dataset = MNISTSuperpixels(path, args.dataset, True,
                                                 pre_transform=pre_transform, coord=coord,
                                                 processed_file_prefix="data_%s" % feat_str)
                    test_dataset = MNISTSuperpixels(path, args.dataset, False,
                                                pre_transform=pre_transform, coord=coord,
                                                processed_file_prefix="data_%s" % feat_str)
                dataset = (train_dataset, test_dataset)
            else:
                # dataset = TUDatasetExt(
                #     path, name, pre_transform=pre_transform,
                #     use_node_attr=True)
                dataset = TUDataset(path, args.dataset,
                                    pre_transform=pre_transform,
                                    use_node_attr=True)
                dataset = dataset.shuffle()
                # embed()
                # exit()
                labels = dataset.y
                # 使用scatter方法将0转换为[0, 1]，1转换为[1, 0]
                one_hot_labels = torch.zeros((labels.size(0), 2))
                one_hot_labels.scatter_(1, (1-labels).unsqueeze(1), 1)

                dataset.data['y'] = one_hot_labels

                dataset.data.edge_attr = None

            return dataset
    else:
        raise ValueError('Unlabeled dataset {} not supported'.format(load_unlabeled_name))
