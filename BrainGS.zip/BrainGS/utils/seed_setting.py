import os
import random
import numpy as np
import torch
# import dgl


seed=2

def seed_torch(seed=seed):
	random.seed(seed)
	os.environ['PYTHONHASHSEED'] = str(seed) # 为了禁止hash随机化，使得实验可复现
	# os.environ['CUBLAS_WORKSPACE_CONFIG'] = ":4096:8"
	np.random.seed(seed)
	torch.manual_seed(seed)
	torch.cuda.manual_seed(seed)
	torch.cuda.manual_seed_all(seed) # if you are using multi-GPU.
	torch.backends.cudnn.deterministic = True
	# torch.backends.cudnn.benchmark = False
	# torch.backends.cudnn.enabled = True
	# torch.use_deterministic_algorithms(True)
	os.environ['OMP_NUM_THREADS']='1'
	os.environ['MKL_NUM_THREADS']='1'

	torch.set_num_threads(1)
	# dgl.random.seed(seed)
	# dgl.seed(seed)
