import time
import torch
from tqdm import trange
from torch_geometric.loader import DataLoader
from torch_geometric.data import Data, InMemoryDataset
import seaborn as sns
from .sde import VESDE
from .infonce import InfoNCE
from .solver import LangevinCorrector, ReverseDiffusionPredictor, mask_x, mask_adjs, gen_noise, get_score_fn
import networkx as nx
from .mol_utils import convert_dense_to_rawpyg, convert_sparse_to_dense, convert_sparse_to_dense_brain, combine_graph_inputs, convert_dense_adj_to_sparse_with_attr, convert_sparse_to_dense_graph
from .mol_utils import extract_graph_feature, estimate_feature_embs, extract_graph_feature_brain, quantize_brain
import matplotlib.pyplot as plt
import numpy as np
from nilearn import plotting
from nilearn import connectome
from nilearn import datasets
from utils.seed_setting import seed_torch,seed
seed_torch()
from matplotlib import cm
from matplotlib.colors import Normalize
from sklearn.manifold import TSNE
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.preprocessing import StandardScaler
import seaborn as sns
from utils.seed_setting import seed_torch,seed
seed_torch(seed)


atlas = datasets.fetch_atlas_aal()
atlas_img = atlas.maps
atlas_region_coords = plotting.find_parcellation_cut_coords(atlas_img)
labels = atlas.labels
# coords = len(atlas['labels'])


__all__ = ['build_augmentation_dataset']

cls_criterion = torch.nn.BCEWithLogitsLoss(reduction='none')
reg_criterion = torch.nn.MSELoss(reduction='none')

# -------- get negative samples for infoNCE loss --------
def get_negative_indices(y_true, n_sample=10):
    if torch.isnan(y_true).sum() != 0:
        print('y_true', (y_true==y_true).size(), (y_true==y_true).sum())
        return None
    y_true = torch.nan_to_num(y_true, nan=0.)
    task_num = y_true.size(1)
    diffs = torch.abs(y_true.view(-1,1,task_num) - y_true.view(1,-1,task_num)).mean(dim=-1)
    diffs_desc_indices = torch.argsort(diffs, dim=1, descending=True)
    return diffs_desc_indices[:, :n_sample]


def inner_sampling(args, generator, x, adj, sde_x, sde_adj, diff_steps, flags=None):
    score_fn_x = get_score_fn(sde_x, generator['model_x'], perturb_ratio=args.perturb_ratio)
    score_fn_adj = get_score_fn(sde_adj, generator['model_adj'], perturb_ratio=args.perturb_ratio)
    snr, scale_eps, n_steps= args.snr, args.scale_eps, args.n_steps
    predictor_obj_x = ReverseDiffusionPredictor('x', sde_x, score_fn_x, False, perturb_ratio=args.perturb_ratio)
    corrector_obj_x = LangevinCorrector('x', sde_x, score_fn_x, snr, scale_eps, n_steps, perturb_ratio=args.perturb_ratio)
    predictor_obj_adj = ReverseDiffusionPredictor('adj', sde_adj, score_fn_adj, False, perturb_ratio=args.perturb_ratio)
    corrector_obj_adj = LangevinCorrector('adj', sde_adj, score_fn_adj, snr, scale_eps, n_steps, perturb_ratio=args.perturb_ratio)
    x, adj = mask_x(x, flags), mask_adjs(adj, flags)
    total_sample_steps = args.out_steps
    timesteps = torch.linspace(1, 1e-3, total_sample_steps, device=args.device)[-diff_steps:]
    with torch.no_grad():
        # -------- Reverse diffusion process --------
        for i in range(diff_steps):
            t = timesteps[i]
            vec_t = torch.ones(adj.shape[0], device=t.device) * t
            _x = x
            x, x_mean = corrector_obj_x.update_fn(x, adj, flags, vec_t)
            adj, adj_mean = corrector_obj_adj.update_fn(_x, adj, flags, vec_t)
            _x = x
            x, x_mean = predictor_obj_x.update_fn(x, adj, flags, vec_t)
            adj, adj_mean = predictor_obj_adj.update_fn(_x, adj, flags, vec_t)
    return x_mean.detach(), adj_mean.detach()

## -------- Main function for augmentation--------##
def build_augmentation_dataset(args, model, generator, labeled_data):
    if args.dataset.startswith('nx'):
        raise NotImplementedError(f"currently not implemented.")

    infonce_paired = InfoNCE(temperature=0.05)
    if 'classification' in args.task_type:
        criterion = cls_criterion
        prob_func = torch.nn.Sigmoid()
    else:
        criterion = reg_criterion

    if args.dataset not in ['ABIDE', 'ADHD200', "OSF","NC1"]:
        label_split_idx = labeled_data.get_idx_split()
        labeled_trainloader = DataLoader(labeled_data[label_split_idx["train"]], batch_size=args.aug_batch,
                                         shuffle=False, num_workers=0)
    else:
        labeled_trainloader = DataLoader(labeled_data, batch_size=args.aug_batch,
                                         shuffle=False, num_workers=0)
    kept_pyg_list = []
    augmented_pyg_list = []
    augment_fails = 0


    

    for step, batch_data in enumerate(labeled_trainloader):
        model.eval()
        batch_data_list = batch_data.to_data_list()
        batch_data = batch_data.to(args.device)
        if batch_data.x.shape[0] > 1:
            with torch.no_grad():
                if args.dataset not in ['ABIDE', 'ADHD200', "OSF","NC1"]:
                    y_pred_logits = model(batch_data)[0]
                else:
                    y_pred_logits = model(batch_data)

            y_true_all, batch_index = batch_data.y.to(torch.float32), batch_data.batch
            is_labeled = y_true_all == y_true_all
            y_pred_logits[~is_labeled], y_true_all[~is_labeled] = 0, 0

            selected_topk = args.topk
            if args.topk > y_true_all.size(0):
                selected_topk = y_true_all.size(0)
                print('reset topk to: ', selected_topk)

            topk_indices = torch.topk(criterion(y_pred_logits.view(y_true_all.size()).to(torch.float32), y_true_all).view(y_true_all.size()).sum(dim=-1), selected_topk, largest=False, sorted=True).indices
            augment_mask = torch.zeros(y_pred_logits.size(0)).to(y_pred_logits.device).scatter_(0, topk_indices, 1).bool()
            augment_labels = y_true_all[augment_mask]

            if args.strategy.split('_')[0] == 'add':
                kept_indices = list(range(y_pred_logits.size(0)))
            elif args.strategy.split('_')[0] == 'replace':
                kept_indices = (~augment_mask).nonzero().view(-1).cpu().tolist()
            elif args.strategy.split('_')[-1] == 'only':
                kept_indices = topk_indices.cpu().tolist()

            else:
                raise NotImplementedError(f"not implemented strategy {args.strategy}.")
            for kept_index in kept_indices:
                kept_pyg_list.append(batch_data_list[kept_index])

            if args.dataset in ['ABIDE', 'ADHD200', "OSF"]:
                batch_dense_x, batch_dense_enable_adj, batch_node_mask = convert_sparse_to_dense_brain(batch_index,
                                                                                                       batch_data.x,
                                                                                                       batch_data.edge_index,
                                                                                                       batch_data.edge_attr)
                batch_dense_x_disable = None
            elif args.dataset in ['NC1']:
                batch_dense_x,  batch_dense_enable_adj,  batch_node_mask, _, _ = \
                    convert_sparse_to_dense_graph(batch_index, batch_data.x, batch_data.edge_index,
                                                  batch_data, augment_mask=None)
                batch_dense_x_disable = None
            else:
                batch_dense_x, batch_dense_x_disable, batch_dense_enable_adj, batch_dense_disable_adj, batch_node_mask = \
                    convert_sparse_to_dense(batch_index, batch_data.x, batch_data.edge_index, batch_data.edge_attr,
                                            augment_mask=None)
            # if args.dataset not in ['ABIDE', 'ADHD200', "OSF"]:
            #     batch_dense_x, batch_dense_x_disable, batch_dense_enable_adj, batch_dense_disable_adj, batch_node_mask = \
            #     convert_sparse_to_dense(batch_index, batch_data.x, batch_data.edge_index, batch_data.edge_attr, augment_mask=None)
            # elif args.dataset not in ['NC1']:
            #     batch_dense_x, batch_dense_x_disable, batch_dense_enable_adj, batch_dense_disable_adj, batch_node_mask = \
            #     convert_sparse_to_dense_graph(batch_index, batch_data.x, batch_data.edge_index, batch_data.edge_attr, augment_mask=None)
            # else:
            #     batch_dense_x, batch_dense_enable_adj, batch_node_mask = convert_sparse_to_dense_brain(batch_index, batch_data.x, batch_data.edge_index, batch_data.edge_attr)
            #     batch_dense_x_disable = None



            if batch_dense_x_disable is None:
                ori_x, ori_adj = batch_dense_x.clone(), batch_dense_enable_adj.clone()
            else:
                ori_x, ori_adj = combine_graph_inputs(*convert_sparse_to_dense(batch_index, batch_data.x, batch_data.edge_index, batch_data.edge_attr, augment_mask=None, return_node_mask=False))
            ori_x, ori_adj = ori_x.to(torch.float32), ori_adj.to(torch.float32)



            # visualize_weighted_graph(ori_adj, title='Original Graph')
            # visualize_unweighted_graph(ori_adj)
            ## extract graph feature
            if args.dataset not in ['ABIDE', 'ADHD200', "OSF","NC1"]:
                ori_feats = extract_graph_feature(ori_x, ori_adj, node_mask=batch_node_mask)
            else:
                ori_feats = extract_graph_feature_brain(ori_x, ori_adj, node_mask=batch_node_mask)

            neg_indices = get_negative_indices(y_true_all, n_sample=args.n_negative) # B x n_sample
            neg_indices = neg_indices[augment_mask]
        
            # sde
            total_sample_steps = args.out_steps
            sde_x = VESDE(sigma_min=0.1, sigma_max=1, N=total_sample_steps)
            sde_adj = VESDE(sigma_min=0.1, sigma_max=1, N=total_sample_steps)
            
    
            batch_dense_x, batch_dense_enable_adj = batch_dense_x[augment_mask], batch_dense_enable_adj[augment_mask]
            if batch_dense_x_disable is not None:
                batch_dense_x_disable, batch_dense_disable_adj = batch_dense_x_disable[augment_mask], batch_dense_disable_adj[augment_mask]

            # perturb x 
            peturb_t = torch.ones(batch_dense_enable_adj.shape[0]).to(args.device) * (sde_adj.T - 1e-3) + 1e-3
            mean_x, std_x = sde_x.marginal_prob(batch_dense_x, peturb_t)
            z_x = gen_noise(batch_dense_x, flags=batch_node_mask[augment_mask], sym=False, perturb_ratio=args.perturb_ratio)
            perturbed_x = mean_x + std_x[:, None, None] * z_x
            perturbed_x = mask_x(perturbed_x, batch_node_mask[augment_mask])
            
            # perturb adj
            mean_adj, std_adj = sde_adj.marginal_prob(batch_dense_enable_adj, peturb_t)
            z_adj = gen_noise(batch_dense_enable_adj, flags=batch_node_mask[augment_mask], sym=True, perturb_ratio=args.perturb_ratio)
            perturbed_adj = mean_adj + std_adj[:, None, None] * z_adj
            perturbed_adj = mask_adjs(perturbed_adj, batch_node_mask[augment_mask])


            for i in range(len(ori_adj)):
                plt.figure(figsize=(8, 6))
                sns.heatmap(np.array(perturbed_adj[i].cpu()), cmap='RdBu_r', annot=False, cbar=True, square=True,
                            xticklabels=False, yticklabels=False)
                plt.title('oriadj Adjacency Matrix Heatmap')
                plt.show()

            # plt.figure(figsize=(8, 6))
            # sns.heatmap(np.array(perturbed_adj[0].cpu()), cmap='Greys', annot=False, cbar=True, square=True,
            #             xticklabels=False, yticklabels=False)
            # plt.title('perturbed_adj Adjacency Matrix Heatmap')
            # plt.show()

            # visualize_weighted_graph(perturbed_adj, title='Perturbed Graph')
            # visualize_unweighted_graph(ori_adj)



            #
            # plotting.plot_connectome(np.array(perturbed_adj[0].cpu()), atlas_region_coords, title='perturbed', display_mode='y',
            #                          node_size=100, edge_threshold='99%')
            # plotting.show()
            timesteps = torch.linspace(1, 1e-3, total_sample_steps, device=args.device)[-args.out_steps:]
            def get_aug_grads(prediction_model, inner_output_data, args):
                prediction_model.eval()
                inner_output_x, inner_output_adj = inner_output_data
                inner_output_adj = mask_adjs(inner_output_adj, batch_node_mask[augment_mask])
                inner_output_x = mask_x(inner_output_x, batch_node_mask[augment_mask])

                inner_output_x,  inner_output_adj = inner_output_x.requires_grad_(), inner_output_adj.requires_grad_()
                with torch.enable_grad():
                    if batch_dense_x_disable is None:
                        inner_x_all, inner_adj_all = inner_output_x, inner_output_adj
                    else:
                        inner_x_all, inner_adj_all = combine_graph_inputs(inner_output_x, batch_dense_x_disable, inner_output_adj, batch_dense_disable_adj, mode='continuous')

                    edge_index, edge_attr = convert_dense_adj_to_sparse_with_attr(inner_adj_all, batch_node_mask[augment_mask])
                    bdata_batch_index = batch_node_mask[augment_mask].nonzero()[:,0]
                    bdata_y = augment_labels.view(inner_x_all.size(0), -1)
                    node_feature_encoded = estimate_feature_embs(inner_x_all[batch_node_mask[augment_mask]], batch_data, prediction_model, obj='node',args=args)
                    edge_attr_encoded = estimate_feature_embs(edge_attr, batch_data, prediction_model, obj='edge',args=args)
                    bdata = Data(x=node_feature_encoded, edge_index=edge_index, edge_attr=edge_attr_encoded, y=bdata_y, batch=bdata_batch_index)
                    
                    if inner_output_x.shape[0] > 1:
                        if args.dataset not in ['ABIDE', 'ADHD200', "OSF","NC1"]:
                            preds = prediction_model(bdata, encode_raw=False)[0]
                        else:
                            preds = prediction_model(bdata)
                        is_labeled = bdata.y == bdata.y
                        bdata_target = bdata.y.to(torch.float32)[is_labeled]
                        if 'classification' in args.task_type:
                            bdata_probs = prob_func(preds.view(bdata.y.size()).to(torch.float32)[is_labeled])
                            loss_y = torch.log((bdata_probs * bdata_target + (1 - bdata_probs) * (1 - bdata_target)).clamp_min(1e-18)).mean() # maximize log likelihood
                        else:
                            loss_y = - reg_criterion(preds.view(bdata.y.size()).to(torch.float32)[is_labeled], bdata_target).mean()

                        if args.dataset not in ['ABIDE', 'ADHD200', "OSF","NC1"]:
                            aug_feats = extract_graph_feature(inner_x_all, inner_adj_all, node_mask=batch_node_mask[augment_mask])
                        else:
                            aug_feats = extract_graph_feature_brain(inner_x_all, inner_adj_all,
                                                              node_mask=batch_node_mask[augment_mask])
                        query_structure_embed, pos_structure_embed, neg_structure_embed = aug_feats, ori_feats[augment_mask], ori_feats[neg_indices]
                        loss_structure = infonce_paired(query_structure_embed, pos_structure_embed, neg_structure_embed) # maximize infonce == minimize mutual information                        

                        # loss_y : I2, loss_structure： I1
                        total_loss = 1*loss_y + 1*loss_structure
    
                        aug_grad_x, aug_grad_adj = torch.autograd.grad(total_loss, [inner_output_x, inner_output_adj])
                    else:
                        aug_grad_x, aug_grad_adj = None, None

                return aug_grad_x, aug_grad_adj

            score_fn_x = get_score_fn(sde_x, generator['model_x'], perturb_ratio=args.perturb_ratio)
            score_fn_adj = get_score_fn(sde_adj, generator['model_adj'], perturb_ratio=args.perturb_ratio)
            predictor_obj_x = ReverseDiffusionPredictor('x', sde_x, score_fn_x, False, perturb_ratio=args.perturb_ratio)
            corrector_obj_x = LangevinCorrector('x', sde_x, score_fn_x, args.snr, args.scale_eps, args.n_steps, perturb_ratio=args.perturb_ratio)
            predictor_obj_adj = ReverseDiffusionPredictor('adj', sde_adj, score_fn_adj, False, perturb_ratio=args.perturb_ratio)
            corrector_obj_adj = LangevinCorrector('adj', sde_adj, score_fn_adj, args.snr, args.scale_eps, args.n_steps, perturb_ratio=args.perturb_ratio)

            if args.no_print:
                outer_iters = range(args.out_steps)
            else:
                outer_iters = trange(0, (args.out_steps), desc = '[Outer Sampling]', position = 1, leave=False)
            for i in outer_iters:
                inner_output_x, inner_output_adj = inner_sampling(args, generator, perturbed_x, perturbed_adj, sde_x, sde_adj, args.out_steps-i, batch_node_mask[augment_mask])
                aug_grad_x, aug_grad_adj = get_aug_grads(model, [inner_output_x, inner_output_adj], args)
                # visualize_weighted_graph(aug_grad_adj,"aug_grad_adj")
                with torch.no_grad():
                    t = timesteps[i]
                    vec_t = torch.ones(perturbed_adj.shape[0], device=t.device) * t
                    _x = perturbed_x
                    perturbed_x, perturbed_x_mean = corrector_obj_x.update_fn(perturbed_x, perturbed_adj, batch_node_mask[augment_mask], vec_t, aug_grad=aug_grad_x)
                    perturbed_adj, perturbed_adj_mean = corrector_obj_adj.update_fn(_x, perturbed_adj, batch_node_mask[augment_mask], vec_t, aug_grad=aug_grad_adj)
                    visualize_weighted_graph(aug_grad_adj, "perturbed_adj_corrector")
                    visualize_weighted_graph(perturbed_adj_mean, "perturbed_adj_mean_corrector")
                    _x = perturbed_x
                    perturbed_x, perturbed_x_mean = predictor_obj_x.update_fn(perturbed_x, perturbed_adj, batch_node_mask[augment_mask], vec_t, aug_grad=aug_grad_x)
                    perturbed_adj, perturbed_adj_mean = predictor_obj_adj.update_fn(_x, perturbed_adj, batch_node_mask[augment_mask], vec_t, aug_grad=aug_grad_adj)
                    visualize_weighted_graph(aug_grad_adj, "perturbed_adj_predictor")
                    visualize_weighted_graph(perturbed_adj_mean, "perturbed_adj_mean_predictor")
            perturbed_adj_mean = mask_adjs(perturbed_adj_mean, batch_node_mask[augment_mask])
            perturbed_x_mean = mask_x(perturbed_x_mean, batch_node_mask[augment_mask])

            augmented_x, augmented_adj = perturbed_x_mean.cpu(), perturbed_adj_mean.cpu()

            # visualize_weighted_graph(augmented_adj, title='Augmented Graph')
            # visualize_feature(augmented_x, ori_x)

            simil_score_list = []
            for idx, feat in enumerate(augmented_x):
                for idx2, feat2 in enumerate(augmented_x):
                    simil_score = visualize_feature(augmented_x[idx], augmented_x[idx2])
                    simil_score_list.append(simil_score)
            sim_mean = sum(simil_score_list)/len(simil_score_list)
            # sim_total.append(int(sim_mean))
            print(sim_mean)
            pass
            f_g_list = []
            for idx, graph in enumerate(augmented_adj):
                for idx2, graph2 in enumerate(augmented_adj):
                    aug_adj = np.array(graph.cpu())
                    aug_adj2 = np.array(graph2.cpu())
                    f_g = graph_various_calculation(aug_adj2, aug_adj)
                    f_g_list.append(f_g)
            fg_mean = sum(f_g_list) / len(f_g_list)
            # fg_total.append(fg_mean)
            print(fg_mean)
            pass


            # visualize_unweighted_graph(ori_adj)


            # plotting.plot_connectome(np.array(augmented_adj[0].cpu()), atlas_region_coords,
            #                          title='augmented_adj',
            #                          display_mode='y',
            #                          node_size=200, edge_threshold="94%",
            #
            #                          )
            # plotting.show()
            if batch_dense_x_disable is None:
                augmented_x, augmented_adj = augmented_x.clone(), quantize_brain(augmented_adj.clone())
            else:
                augmented_x, augmented_adj = combine_graph_inputs(augmented_x, batch_dense_x_disable, augmented_adj, batch_dense_disable_adj, mode='discrete')

                # Visualization

            batch_augment_pyg_list = convert_dense_to_rawpyg(augmented_x, augmented_adj, augment_labels, n_jobs=args.n_jobs, args=args)

            augment_indices = augment_mask.nonzero().view(-1).cpu().tolist()
            augmented_pyg_list_temp = []
            for pyg_data in batch_augment_pyg_list:
                if not isinstance(pyg_data, int):
                    augmented_pyg_list_temp.append(pyg_data)
                elif args.strategy.split('_')[0] == 'add':
                    pass
                else:
                    augment_fails += 1
                    kept_pyg_list.append(batch_data_list[augment_indices[pyg_data]])

            augmented_pyg_list.extend(augmented_pyg_list_temp)

    # 绘制单变量箱线图
    # sns.boxplot(data=sim_total)
    # plt.title("Single Variable Boxplot")
    # plt.show()
    # sns.boxplot(data=fg_total)
    # plt.title("Single Variable Boxplot")
    # plt.show()
    if args.strategy != 'inverse':
        kept_pyg_list.extend(augmented_pyg_list)


    if args.dataset not in ['ABIDE', 'ADHD200', "OSF","NC1"]:
        new_dataset = NewDataset(kept_pyg_list, num_fail=augment_fails)
    else:
        for idx, g in enumerate(kept_pyg_list):
            try:
                del kept_pyg_list[idx]['pos']
            except:
                pass
        new_dataset = NewDataset(kept_pyg_list, num_fail=augment_fails)
    return new_dataset, fg_mean, sim_mean

def visualize_weighted_graph(adj, title=''):
    # 创建一个图
    G2 = nx.from_numpy_array(np.array(adj[0].cpu()))

    # 获取所有边的权重
    weights = [G2[u][v]['weight'] for u, v in G2.edges()]

    # 计算边的权重的最小值和最大值
    min_weight = min(weights)
    max_weight = max(weights)

    # 选择colormap（你可以根据需要更换colormap）
    cmap = cm.get_cmap("viridis")

    # 正常化权重范围
    norm = Normalize(vmin=min_weight, vmax=max_weight)

    # 绘制图
    plt.figure(figsize=(12, 12))

    # 为每条边设置颜色，根据权重
    edge_colors = [cmap(norm(G2[u][v]['weight'])) for u, v in G2.edges()]

    # 绘制节点
    pos = nx.spring_layout(G2, k=0.08, iterations=10)  # 你可以选择其他布局，spring_layout是力导向布局
    # pos = nx.spectral_layout(G2,scale=0.5)
    # pos = nx.kamada_kawai_layout(G2)


    nx.draw_networkx_nodes(G2, pos, node_size=100, node_color='indianred')

    # 绘制边，使用上述计算的颜色
    nx.draw_networkx_edges(G2, pos, edgelist=G2.edges(), edge_color=edge_colors, width=0.3)

    # 绘制节点标签
    # nx.draw_networkx_labels(G2, pos, font_size=12, font_color='black')

    ax = plt.gca()

    # 添加colorbar作为图例
    sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
    sm.set_array([])  # 为空数组，因为没有实际数据，但colorbar需要它
    plt.colorbar(sm, ax=ax)

    # 设置标题
    plt.title(title)

    # 显示图形
    plt.axis("off")  # 关闭坐标轴
    plt.show()

def visualize_unweighted_graph(adj):
    plt.figure(figsize=(12, 12))
    G2 = nx.from_numpy_array(np.array(adj[0].cpu()))

    # 使用 spring 布局来布局图形
    pos = nx.spring_layout(G2, seed=0, k=0.15, iterations=5)
    # pos = nx.kamada_kawai_layout(G1)
    # 绘制节点，设置节点颜色为黑色，小点
    # nx.draw_networkx_nodes(G2, pos=nx.spring_layout(G2), node_size=100, node_color='black')

    # 绘制边，设置边的颜色为半透明红色，边宽为细边
    # nx.draw_networkx_edges(G2, pos=nx.spring_layout(G2), width=0.7, alpha=0.1, edge_color='red')

    nx.draw(G2, pos, with_labels=False, node_size=100, node_color='red',
            edge_color='grey', width=0.2)
    # 绘制标签（如果需要）
    # nx.draw_networkx_labels(G, pos=nx.spring_layout(G), font_size=12)

    # 显示图
    plt.title("Pertubed Adj")
    plt.axis('off')  # 不显示坐标轴
    plt.show()

def frobenius_norm(A):
    return np.linalg.norm(A, 'fro')

def graph_various_calculation(A, B):
    # 计算 Frobenius 范数
    frobenius_A = frobenius_norm(A)
    frobenius_B = frobenius_norm(B)
    frobenius_g = frobenius_norm(A-B)

    # print(f"Frobenius norm of A: {frobenius_A}")
    # print(f"Frobenius norm of B: {frobenius_B}")
    # print(f"Frobenius norm of A-B: {frobenius_g}")
    return frobenius_g


def visualize_feature(feature1, feature2):
    # feature1 = np.array(feature1[0].cpu())
    # feature2 = np.array(feature2[0].cpu())
    a_flat = feature1.flatten()
    b_flat = feature2.cpu().flatten()
    sim = torch.nn.functional.cosine_similarity(a_flat, b_flat, dim=0)
    return sim
    # print("similarity:", sim)
    # print(f"Similarity between {node1} and {node2}: {sim}")
class NewDataset(InMemoryDataset):
    def __init__(self, data_list, num_fail=0, transform=None, pre_transform=None):
        super().__init__(None, transform, pre_transform)
        self.data_list = data_list
        self.data_len = len(data_list)
        self.num_fail = num_fail
        # print('data_len', self.data_len, 'num_fail', num_fail)
        self.data, self.slices = self.collate(data_list)
    def get_idx_split(self):
        return {'train': torch.arange(self.data_len, dtype = torch.long), 'valid': None, 'test': None}

if __name__ == '__main__':
    pass