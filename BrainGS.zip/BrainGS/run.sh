# Ablation study 1: effectivenes of diffusion model

# without diffusion

# ABIDE DATASET
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 64 --epoch 100 --diffusion_flag False
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 64 --epoch 100 --diffusion_flag False
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 64 --epoch 100 --diffusion_flag False
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 64 --epoch 100 --diffusion_flag False
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 64 --epoch 100 --diffusion_flag False
# OSF DATASET
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 64 --epoch 100 --diffusion_flag False
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 64 --epoch 100 --diffusion_flag False
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 64 --epoch 100 --diffusion_flag False
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 64 --epoch 100 --diffusion_flag False
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 64 --epoch 100 --diffusion_flag False

# With only diffusion

# ABIDE DATASET
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 64 --epoch 100 --diffusion_flag True
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 64 --epoch 100 --diffusion_flag True
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 64 --epoch 100 --diffusion_flag True
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 64 --epoch 100 --diffusion_flag True
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 64 --epoch 100 --diffusion_flag True
# OSF DATASET
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 64 --epoch 150 --diffusion_flag True
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 64 --epoch 150 --diffusion_flag True
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 64 --epoch 150 --diffusion_flag True
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 64 --epoch 150 --diffusion_flag True
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 64 --epoch 150 --diffusion_flag True


# With only I1/I2 , ALL constraint
# ABIDE DATASET
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 50 --epoch 100 --diffusion_flag True
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 50 --epoch 100 --diffusion_flag True
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 50 --epoch 100 --diffusion_flag True
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 50 --epoch 100 --diffusion_flag True
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 50 --epoch 100 --diffusion_flag True
# OSF DATASET
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 64 --epoch 70 --diffusion_flag True
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 64 --epoch 70 --diffusion_flag True
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 64 --epoch 70 --diffusion_flag True
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 64 --epoch 150 --diffusion_flag True
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 64 --epoch 150 --diffusion_flag True

# With ALL constraint
# ABIDE DATASET
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 50 --epoch 100 --diffusion_flag True 
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 50 --epoch 100 --diffusion_flag True 
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 50 --epoch 100 --diffusion_flag True
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 50 --epoch 100 --diffusion_flag True
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 50 --epoch 100 --diffusion_flag True
# OSF DATASET
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 64 --epoch 70 --diffusion_flag True --seed 0
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 64 --epoch 70 --diffusion_flag True --seed 0
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 64 --epoch 70 --diffusion_flag True --seed 0
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 64 --epoch 150 --diffusion_flag True
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 64 --epoch 150 --diffusion_flag True

# Ablation 2
# add
# ABIDE DATASET
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 50 --epoch 100 --diffusion_flag True --strategy replace_only
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 50 --epoch 100 --diffusion_flag True --strategy replace_only
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 50 --epoch 100 --diffusion_flag True --strategy replace_only
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 50 --epoch 100 --diffusion_flag True --strategy replace_only
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 50 --epoch 100 --diffusion_flag True --strategy replace_only
# OSF DATASET
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 70 --epoch 150 --diffusion_flag True --strategy replace_only
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 70 --epoch 150 --diffusion_flag True --strategy replace_only
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 70 --epoch 150 --diffusion_flag True --strategy replace_only
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 70 --epoch 150 --diffusion_flag True --strategy replace_only
#python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 70 --epoch 150 --diffusion_flag True --strategy replace_only

# Ablation 4
# add KG
# ABIDE DATASET
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 50 --epoch 100 --diffusion_flag True
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 50 --epoch 100 --diffusion_flag True
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 50 --epoch 100 --diffusion_flag True
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 50 --epoch 100 --diffusion_flag True
#python main.py --dataset ABIDE --n-negative 1 --out-steps 1 --topk 50 --epoch 100 --diffusion_flag True
# OSF DATASET
python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 70 --epoch 150 --diffusion_flag True
python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 70 --epoch 150 --diffusion_flag True
python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 70 --epoch 150 --diffusion_flag True
python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 70 --epoch 150 --diffusion_flag True
python main.py --dataset OSF --n-negative 1 --out-steps 1 --topk 70 --epoch 150 --diffusion_flag True

