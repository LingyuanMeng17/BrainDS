import math
import time
import datetime
import logging
import os
from tqdm import tqdm
from datetime import datetime
import seaborn as sbs
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.optim as optim
from torch.optim.lr_scheduler import LambdaLR
from torch_geometric.loader import DataLoader
from sklearn.model_selection import StratifiedKFold
from models.gnn import GNN, ResGCN
from configures.test_arguments import load_arguments_from_yaml, get_args
from dataset.get_datasets import get_dataset
from utils import AverageMeter, validate, print_info, init_weights, load_generator, ImbalancedSampler
from utils import build_augmentation_dataset
from utils.seed_setting import seed_torch, seed

seed_torch(seed)
cls_criterion = torch.nn.BCEWithLogitsLoss(reduction='none')
reg_criterion = torch.nn.MSELoss(reduction='none')


def get_logger(name, logfile=None):
    """ create a nice logger """
    logger = logging.getLogger(name)
    # clear handlers if they were created in other runs
    if (logger.hasHandlers()):
        logger.handlers.clear()
    logger.setLevel(logging.DEBUG)
    # create formatter
    formatter = logging.Formatter('%(asctime)s - %(message)s')
    # create console handler add add to logger
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    # create file handler add add to logger when name is not None
    if logfile is not None:
        fh = logging.FileHandler(logfile)
        fh.setFormatter(formatter)
        fh.setLevel(logging.DEBUG)
        logger.addHandler(fh)
    logger.propagate = False
    return logger


def get_cosine_schedule_with_warmup(optimizer,
                                    num_warmup_steps,
                                    num_training_steps,
                                    num_cycles=0.5,
                                    # num_cycles=7./16.,
                                    last_epoch=-1):
    def _lr_lambda(current_step):
        if current_step < num_warmup_steps:
            return float(current_step) / float(max(1, num_warmup_steps))
        no_progress = float(current_step - num_warmup_steps) / \
                      float(max(1, num_training_steps - num_warmup_steps))
        return max(1e-2, math.cos(math.pi * num_cycles * no_progress))

    return LambdaLR(optimizer, _lr_lambda, last_epoch)


def load_checkpoint(model, optimizer, checkpoint_path):
    checkpoint = torch.load(checkpoint_path)
    model.load_state_dict(checkpoint['model_state_dict'])
    optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    start_epoch = checkpoint['epoch']
    print(f"Checkpoint loaded; Resuming from epoch {start_epoch}")
    return start_epoch



def test(args, model, train_loaders, optimizer, scheduler, epoch):
    if args.task_type in 'regression':
        criterion = reg_criterion
    else:
        criterion = cls_criterion
    if not args.no_print:
        p_bar = tqdm(range(args.steps))
    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    device = args.device
    model.test()
    for batch_idx in range(args.steps):
        end = time.time()
        model.zero_grad()
        try:
            batch_labeled = next(train_loaders['labeled_iter'])
        except:
            train_loaders['labeled_iter'] = iter(train_loaders['labeled_trainloader'])
            batch_labeled = next(train_loaders['labeled_iter'])
        batch_labeled = batch_labeled.to(device)
        targets = batch_labeled.y.to(torch.float32)
        is_labeled = targets == targets
        if batch_labeled.x.shape[0] == 1 or batch_labeled.batch[-1] == 0:
            continue
        else:
            if args.dataset not in ["ABIDE", "ADHD200", "OSF", "NC1"]:
                pred_labeled = model(batch_labeled)[0]
            else:
                pred_labeled = model(batch_labeled)

            Losses = criterion(pred_labeled.view(targets.size()).to(torch.float32)[is_labeled], targets[is_labeled])
            loss = Losses.mean()
        loss.backward()
        optimizer.step()
        scheduler.step()
        losses.update(loss.item())
        batch_time.update(time.time() - end)
        end = time.time()
        if not args.no_print:
            p_bar.set_description(
                "Train Epoch: {epoch}/{epochs:4}. Iter: {batch:4}/{iter:4}. LR: {lr:.8f}. Data: {data:.3f}s. Batch: {bt:.3f}s. Loss: {loss:.4f}. ".format(
                    epoch=epoch + 1,
                    epochs=args.epochs,
                    batch=batch_idx + 1,
                    iter=args.steps,
                    lr=scheduler.get_last_lr()[0],
                    data=data_time.avg,
                    bt=batch_time.avg,
                    loss=losses.avg,
                ))
            p_bar.update()
    if not args.no_print:
        p_bar.close()
    return train_loaders


def main(args):
    device = torch.device('cuda', args.gpu_id)
    args.n_gpu = torch.cuda.device_count()
    args.device = device

    if args.dataset in ['ABIDE', 'ADHD200', "OSF", "NC1", "PROTEINS", "MUTAG"]:
        labeled_dataset = get_dataset(args, '')
        ASFF = labeled_dataset.raw_file_names

        args.num_trained = len(ASFF)
        args.num_trained_init = args.num_trained
        args.task_type = 'classification'
        pass
    else:
        labeled_dataset = get_dataset(args, './raw_data')
        label_split_idx = labeled_dataset.get_idx_split()
        args.num_trained = len(label_split_idx["train"])
        args.num_trained_init = args.num_trained
        args.task_type = labeled_dataset.task_type

    args.steps = args.num_trained // args.batch_size + 1
    args.strategy = args.strategy_init

    if args.dataset == 'ogbg-molhiv':
        sampler = ImbalancedSampler(labeled_dataset, label_split_idx["train"])
        labeled_trainloader = DataLoader(labeled_dataset[label_split_idx["train"]], batch_size=args.batch_size,
                                         sampler=sampler, num_workers=args.num_workers)
        valid_loader = DataLoader(labeled_dataset[label_split_idx["valid"]], batch_size=args.batch_size, shuffle=False,
                                  num_workers=args.num_workers)
        test_loader = DataLoader(labeled_dataset[label_split_idx["test"]], batch_size=args.batch_size, shuffle=False,
                                 num_workers=args.num_workers)

    elif args.dataset in ['ABIDE', 'ADHD200', "OSF", "NC1", "PROTEINS", "MUTAG"]:
        train_loader, test_loader, valid_loader, labeled_trainloader, d_loader = benchmark_exp(labeled_dataset, args,
                                                                                               batch_size=args.batch_size)
    else:
        labeled_trainloader = DataLoader(labeled_dataset[label_split_idx["train"]], batch_size=args.batch_size,
                                         shuffle=True, num_workers=args.num_workers)
        valid_loader = DataLoader(labeled_dataset[label_split_idx["valid"]], batch_size=args.batch_size, shuffle=False,
                                  num_workers=args.num_workers)
        test_loader = DataLoader(labeled_dataset[label_split_idx["test"]], batch_size=args.batch_size, shuffle=False,
                                 num_workers=args.num_workers)

    if args.dataset in ['ABIDE', 'ADHD200', "OSF", "NC1"]:
        model = ResGCN(labeled_dataset, args.brain_hidden, args.brain_n_layers_feat, args.brain_n_layers_conv,
                       args.brain_n_layers_fc, gfn=False, collapse=False,
                       residual=args.brain_skip_connection, res_branch=args.brain_res_branch,
                       global_pool=args.brain_global_pool, dropout=args.brain_dropout,
                       edge_norm=args.brain_edge_norm)
        model.to(device)
    else:
        model = GNN(gnn_type=args.model, num_tasks=labeled_dataset.num_tasks, num_layer=args.num_layer,
                    emb_dim=args.emb_dim,
                    drop_ratio=args.drop_ratio, graph_pooling=args.readout, norm_layer=args.norm_layer).to(device)

    if args.dataset == 'ABIDE':
        generator = load_generator(device, path='checkpoints/ABIDE.pth')
    elif args.dataset == 'ADHD200':
        generator = load_generator(device, path='checkpoints/ADHD200.pth')
    elif args.dataset == "OSF":
        generator = load_generator(device, path='checkpoints/OSF.pth')
    else:
        generator = load_generator(device, path='checkpoints/qm9_denoise.pth')

    if args.dataset not in ['ABIDE', 'ADHD200', "OSF"]:
        init_weights(model, args.initw_name, init_gain=0.02)

    if args.dataset not in ['ABIDE', 'ADHD200', "OSF"]:
        optimizer = optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.wdecay)
    else:
        optimizer = optim.Adam(model.parameters(), lr=args.brain_lr, weight_decay=0)

    scheduler = get_cosine_schedule_with_warmup(optimizer, 0, 100)
    logging.warning(f"device: {args.device}, " f"n_gpu: {args.n_gpu}, ")
    logger.info(dict(args._get_kwargs()))
    logger.info("***** Running training *****")

    if args.dataset not in ['ABIDE', 'ADHD200', "OSF", "NC1"]:
        logger.info(
            f"  Task = {args.dataset}@{args.num_trained}/{len(label_split_idx['valid'])}/{len(label_split_idx['test'])}")

    logger.info(f"  Num Epochs = {args.epochs}")
    logger.info(f"  Total train batch size = {args.batch_size}")
    logger.info(f"  Total optimization steps = {args.epochs * args.steps}")
    train_loaders = {'labeled_iter': iter(labeled_trainloader), 'labeled_trainloader': labeled_trainloader}
    diffusion_flag = args.diffusion_flag

    fg_total = []
    sim_total = []

    checkpoint_path = "/checkpoints/OSF/epoch150_topk64_semi_split30_best.pth"
    start_epoch = load_checkpoint(model, optimizer, checkpoint_path)
    test_perf = validate(args, model, test_loader)
    print_info('Test', test_perf)


    return 0


def benchmark_exp(dataset, args, batch_size):
    dataset_size = len(dataset)
    semi_size = int(dataset_size * args.semi_split / 100)
    if args.dataset in ['ABIDE', 'ADHD200', "OSF"]:
        datalen = len(dataset.raw_file_names)
    else:
        datalen = dataset_size
    tensor = torch.tensor(range(datalen))
    split_ratio = 0.8

    # Determine the number of elements in each split
    num_train = int(len(tensor) * split_ratio)
    num_test = len(tensor) - num_train

    # Generate random indices for the split
    indices = torch.randperm(len(tensor))

    # Split the indices into training and testing sets
    train_indices = indices[:num_train]
    test_indices = indices[num_train:]
    valid_indices = test_indices

    train_size = train_indices.shape[0]
    select_idx = torch.randperm(train_size)[:semi_size]
    semi_indice = train_indices[select_idx]

    # train_dataset = dataset[train_idx]
    train_dataset = dataset[train_indices]
    # val_dataset = dataset[val_idx]
    test_dataset = dataset[test_indices]
    valid_dataset = dataset[valid_indices]
    semi_dataset = dataset[semi_indice]

    # train_loader = DataLoader(train_dataset, batch_size, shuffle=True)
    train_loader = DataLoader(train_dataset, batch_size, shuffle=True)
    # val_loader = DataLoader(val_dataset, batch_size, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size, shuffle=False)
    valid_loader = DataLoader(valid_dataset, batch_size, shuffle=False)
    semi_loader = DataLoader(semi_dataset, batch_size, shuffle=True)

    D_loader = DataLoader(dataset, 1, shuffle=False)

    return train_loader, test_loader, valid_loader, semi_loader, D_loader


def cl_k_fold(dataset, folds, epoch_select, semi_split):
    skf = StratifiedKFold(folds, shuffle=True, random_state=12345)

    test_indices, train_indices = [], []

    semi_indices = []
    for _, idx in skf.split(torch.zeros(len(dataset)), dataset.data.y):
        test_indices.append(torch.from_numpy(idx))

    if epoch_select == 'test_max':
        val_indices = [test_indices[i] for i in range(folds)]
    else:
        val_indices = [test_indices[i - 1] for i in range(folds)]

    dataset_size = len(dataset)
    semi_size = int(dataset_size * semi_split / 100)

    for i in range(folds):
        train_mask = torch.ones(len(dataset), dtype=torch.uint8)
        train_mask[test_indices[i].long()] = 0
        train_mask[val_indices[i].long()] = 0
        train_indice = torch.nonzero(train_mask, as_tuple=False).view(-1)
        train_indices.append(train_indice)

        # semi split
        train_size = train_indice.shape[0]
        select_idx = torch.randperm(train_size)[:semi_size]
        semi_indice = train_indice[select_idx]
        semi_indices.append(semi_indice)
    # embed()
    # exit()
    return train_indices, test_indices, val_indices, semi_indices



args = get_args()

config = load_arguments_from_yaml(f'configures/{args.dataset}.yaml')
for arg, value in config.items():
    setattr(args, arg, value)

args.strategy_init = args.strategy
datetime_now = datetime.now().strftime("%Y%m%d.%H%M%S")
logger = get_logger(__name__, logfile=None)
print(args)
results = {}
for exp_num in range(args.trails):
    seed_torch(exp_num)
    args.exp_num = exp_num
    main(args)
